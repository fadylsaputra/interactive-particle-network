const canvas = document.getElementById("particleCanvas");
const ctx = canvas.getContext("2d");

let width;
let height;
let particles = [];

const CONFIG = {
  particleCount: 95,

  // Jarak maksimum dua titik agar terhubung
  connectionDistance: 155,

  // Area pengaruh cursor
  mouseRadius: 145,

  // Kekuatan dorongan cursor
  mouseForce: 2.8,

  // Kecepatan gerak normal
  speed: 0.22,

  // Ukuran titik
  particleSize: 1.4
};

const mouse = {
  x: null,
  y: null,
  active: false
};

function resizeCanvas() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);

  width = window.innerWidth;
  height = window.innerHeight;

  canvas.width = width * dpr;
  canvas.height = height * dpr;
  canvas.style.width = width + "px";
  canvas.style.height = height + "px";

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

class Particle {
  constructor() {
    this.x = Math.random() * width;
    this.y = Math.random() * height;

    this.vx = (Math.random() - 0.5) * CONFIG.speed;
    this.vy = (Math.random() - 0.5) * CONFIG.speed;

    this.baseSize =
      CONFIG.particleSize * (0.7 + Math.random() * 0.7);
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;

    // Pantul dari sisi layar
    if (this.x <= 0 || this.x >= width) {
      this.vx *= -1;
      this.x = Math.max(0, Math.min(width, this.x));
    }

    if (this.y <= 0 || this.y >= height) {
      this.vy *= -1;
      this.y = Math.max(0, Math.min(height, this.y));
    }

    // Mouse repulsion
    if (mouse.active) {
      const dx = this.x - mouse.x;
      const dy = this.y - mouse.y;
      const distance = Math.hypot(dx, dy);

      if (distance > 0 && distance < CONFIG.mouseRadius) {
        const strength =
          Math.pow(
            (CONFIG.mouseRadius - distance) / CONFIG.mouseRadius,
            2
          ) * CONFIG.mouseForce;

        this.x += (dx / distance) * strength;
        this.y += (dy / distance) * strength;
      }
    }
  }

  draw() {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.baseSize, 0, Math.PI * 2);

    ctx.fillStyle = "rgba(255, 45, 125, 0.85)";
    ctx.shadowBlur = 8;
    ctx.shadowColor = "rgba(255, 20, 100, 0.55)";
    ctx.fill();

    ctx.shadowBlur = 0;
  }
}

function createParticles() {
  particles = [];

  for (let i = 0; i < CONFIG.particleCount; i++) {
    particles.push(new Particle());
  }
}

function drawConnections() {
  for (let i = 0; i < particles.length; i++) {
    for (let j = i + 1; j < particles.length; j++) {
      const a = particles[i];
      const b = particles[j];

      const distance = Math.hypot(
        a.x - b.x,
        a.y - b.y
      );

      if (distance < CONFIG.connectionDistance) {
        // Dekat = lebih contrast
        const opacity =
          Math.pow(
            1 - distance / CONFIG.connectionDistance,
            1.5
          ) * 0.65;

        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);

        ctx.lineWidth = 0.7;
        ctx.strokeStyle =
          `rgba(255, 20, 100, ${opacity})`;

        ctx.stroke();
      }
    }
  }
}

function animate() {
  ctx.clearRect(0, 0, width, height);

  for (const particle of particles) {
    particle.update();
  }

  drawConnections();

  for (const particle of particles) {
    particle.draw();
  }

  requestAnimationFrame(animate);
}

window.addEventListener("mousemove", (event) => {
  mouse.x = event.clientX;
  mouse.y = event.clientY;
  mouse.active = true;
});

window.addEventListener("mouseleave", () => {
  mouse.active = false;
});

window.addEventListener("resize", () => {
  resizeCanvas();
  createParticles();
});

resizeCanvas();
createParticles();
animate();
